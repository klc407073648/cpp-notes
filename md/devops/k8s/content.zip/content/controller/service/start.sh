cd ./myweb/deploy/ && ./myprj
